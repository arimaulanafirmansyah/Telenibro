# Telegram Userbot (API Dev) — Termux Edition — v2

Script ini jalan sebagai **akun user Telegram kamu** (bukan bot BotFather),
pakai `api_id` & `api_hash` dari https://my.telegram.org.
Itu satu-satunya cara supaya script bisa **bikin grup + nambahin member**
(Bot API biasa tidak bisa melakukan keduanya).

## Fitur v2

### Menu Accounts
1. **Add new account** — tambah akun (multi akun). Isi nama, `api_id`,
   `api_hash`, nomor HP, lalu kode OTP dari Telegram (dan password 2FA
   kalau ada). Sesi login tersimpan di folder `sessions/`.
2. **Filter all banned accounts** — cek semua akun satu per satu: yang
   masih bisa login = OK, yang sesinya sudah tidak berlaku / akunnya
   kena banned = BANNED. Akun yang tidak jelas hasilnya (mis. jaringan)
   dilaporkan terpisah.
3. **Delete specific account** — hapus akun dari daftar + file sesinya
   (konfirmasi ketik `y` dulu).
4. **Display all accounts** — tampilkan semua akun (nama, nomor, api_id,
   api_hash tersensor, penanda akun aktif).
5. **Set active account** — pilih akun yang dipakai untuk semua aksi
   (buat grup, tambah member). Kalau cuma ada 1 akun, otomatis dipakai.

### Menu utama
- **Buat grup baru** (supergroup) + invite link otomatis tampil, info grup
  disimpan di `group.json`.
- **Tambah member dari members.txt** ke grup tersimpan (satu username
  per baris, boleh pakai @ atau tidak).
- **Tambah member dari grup lain** — alurnya:
  1. Input link grup **tujuan**
  2. Input link grup **sumber** (grup random mana pun)
  3. Script dump semua username dari grup sumber (disimpan juga ke file
     `dump_<nama grup>_<id>.txt`)
  4. Pilih mau invite berapa (Enter = semua), konfirmasi, lalu invite
     satu per satu ke grup tujuan
- **Info grup tersimpan** (nama, ID, jumlah member, invite link).

## 1. Siapkan API dev (sekali saja, per akun)

1. Buka https://my.telegram.org di browser HP, login pakai nomor Telegram
   akun tersebut.
2. Buat App (isi nama app + platform bebas, mis. "userbot").
3. Catat `api_id` dan `api_hash` yang muncul. Satu akun Telegram = satu
   pasang api_id/api_hash (boleh pakai yang sama untuk semua akun, tapi
   tiap akun tetap login pakai nomornya sendiri).

## 2. Install di Termux

```bash
pkg update && pkg install python unzip -y
termux-setup-storage
cd ~/storage/downloads
unzip telegram-userbot.zip
cd telegram-userbot
pip install -r requirements.txt
python main.py
```

Tidak perlu edit file konfigurasi manual — semua akun ditambahkan lewat
menu Accounts di dalam script.

## 3. Pakai

```bash
python main.py
```

- **Pertama kali:** buka menu `1. Accounts` → `1. Add new account`.
  Masukkan nama, api_id, api_hash, nomor HP (format +62...), lalu kode
  OTP yang dikirim Telegram. Kalau akun pakai verifikasi 2 langkah,
  masukkan juga password-nya.
- **Akun pertama** otomatis jadi akun aktif. Kalau ada banyak akun,
  atur lewat menu Accounts → `5. Set active account`.
- **Jalan berikutnya** tidak perlu OTP lagi (sesi tersimpan).
- Isi `members.txt` dulu sebelum pakai menu tambah member dari file.

Catatan migrasi dari v1: kalau kamu sudah pernah jalanin v1 (pakai
`.env` + `userbot_session.session`), script v2 otomatis mengimpor akun
itu jadi `akun1` saat pertama jalan — tidak perlu login ulang.

## Batasan Telegram (penting)

- **FloodWait:** Telegram membatasi seberapa cepat akun menambah member.
  Kalau kena, script otomatis tidur selama waktu yang diminta Telegram.
  Kalau FloodWait berulang, istirahatkan akun dulu, lanjutkan lagi nanti.
- **Privasi target:** user yang mengatur "siapa yang bisa menambahkanku"
  ke kontak saja tidak bisa ditambahkan — script akan melewatinya (LEWAT).
- **Akun tujuan harus admin:** akun yang dipakai invite harus jadi admin
  (atau pembuat) grup tujuan, kalau tidak proses berhenti dengan pesan
  yang jelas.
- **Grup sumber:** akun harus sudah jadi member grup sumber untuk bisa
  dump membernya. Untuk link invite privat, akun akan join dulu otomatis.
- **Jangan gaspol:** jeda antar member (`add_delay`, default 15 detik,
  bisa diubah di `accounts.json`) sengaja ada supaya akunmu tidak
  dianggap spam. Makin besar jedanya, makin aman.

## Keamanan — baca ini

- **JANGAN** kirim file `accounts.json` dan isi folder `sessions/` ke
  siapa pun, termasuk lewat chat. Keduanya = akses penuh ke akun-akun
  Telegram kamu (api_hash + kunci sesi ada di dalamnya).
- Kode OTP hanya dimasukkan di Termux kamu sendiri, tidak pernah dikirim
  ke chat atau ke pihak lain.
- Kalau ganti HP / sesi bocor: hapus akun dari menu Accounts (atau hapus
  file sesinya), lalu cabut sesi lama dari Telegram → Settings → Devices.

## File dalam paket

| File | Fungsi |
|---|---|
| `main.py` | Script utama (semua menu & fitur) |
| `accounts.json` | Daftar akun + akun aktif + jeda invite (dibuat/diisi otomatis) |
| `sessions/` | File sesi login per akun (dibuat otomatis, jangan dibagikan) |
| `requirements.txt` | Dependensi Python (telethon) |
| `members.txt` | Daftar username untuk menu tambah member dari file |
| `group.json` | Otomatis dibuat saat grup dibuat (info grup tersimpan) |
| `dump_*.txt` | Otomatis dibuat saat dump dari grup sumber |
| `README.md` | File ini |
