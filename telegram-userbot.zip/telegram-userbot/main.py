#!/usr/bin/env python3
"""
Telegram Userbot (MTProto / API Dev) - Termux Edition - v2
===========================================================
Script ini jalan sebagai AKUN USER Telegram (bukan bot BotFather),
pakai api_id & api_hash dari https://my.telegram.org.

Fitur v2:
  Menu Accounts
    1. Add new account (multi akun)
    2. Filter all banned accounts (cek akun mana yang kena banned)
    3. Delete specific account
    4. Display all accounts
    5. Set active account (akun yang dipakai buat semua aksi)
  Menu utama
    - Buat grup baru (supergroup) + invite link
    - Tambah member dari members.txt ke grup tersimpan
    - Tambah member dari grup lain: input link grup tujuan, input link
      grup sumber, dump username dari grup sumber, invite ke grup tujuan
    - Info grup tersimpan

Semua akun disimpan di accounts.json (beserta api_id & api_hash-nya)
dan sesi login di folder sessions/. KEDUA FILE INI SENSITIF - jangan
dibagikan ke siapa pun, karena sama dengan akses penuh ke akun-akunmu.

Cara pakai (Termux):
  1. pip install -r requirements.txt
  2. python main.py
  3. Masuk menu Accounts -> Add new account, isi nama, api_id, api_hash,
     nomor HP, lalu kode OTP dari Telegram (dan password 2FA kalau ada).
  4. Pilih akun aktif, lalu pakai menu lainnya.

Batasan Telegram (penting):
  - Penambahan member dibatasi (flood control + setelan privasi target).
    Script otomatis jeda kalau kena FloodWait, tapi jangan dipaksa
    tambah ribuan member sekaligus.
  - Akun yang sudah kena banned tidak bisa dipakai lagi; cek lewat
    menu Accounts -> Filter banned accounts.
"""

import asyncio
import json
import os
import re
import shutil
import sys
from pathlib import Path

import telethon.errors as terr
from telethon import TelegramClient
from telethon.errors import (
    ChannelPrivateError,
    ChatAdminRequiredError,
    FloodWaitError,
    InviteHashExpiredError,
    PeerFloodError,
    UserAlreadyParticipantError,
    UserPrivacyRestrictedError,
)
from telethon.tl.functions.channels import (
    CreateChannelRequest,
    GetFullChannelRequest,
    InviteToChannelRequest,
)
from telethon.tl.functions.messages import (
    CheckChatInviteRequest,
    ExportChatInviteRequest,
    ImportChatInviteRequest,
)
from telethon.tl.types import InputUser, PeerChannel

BASE = Path(__file__).resolve().parent
ACCOUNTS_FILE = BASE / "accounts.json"
SESSIONS_DIR = BASE / "sessions"
GROUP_FILE = BASE / "group.json"
MEMBERS_FILE = BASE / "members.txt"
DUMP_DIR = BASE

# Error yang menandakan akun kena banned / sesi sudah tidak berlaku.
_BANNED_NAMES = (
    "AuthKeyUnregisteredError",
    "UserDeactivatedError",
    "UserDeactivatedBanError",
    "AuthKeyDuplicatedError",
    "SessionRevokedError",
)
BANNED_ERRORS = tuple(
    getattr(terr, nama) for nama in _BANNED_NAMES if hasattr(terr, nama)
)


# ---------------------------------------------------------------------------
# Penyimpanan akun
# ---------------------------------------------------------------------------

def data_default():
    return {"active": None, "add_delay": 15, "accounts": []}


def muat_data_akun():
    if not ACCOUNTS_FILE.exists():
        return data_default()
    try:
        data = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
        data.setdefault("active", None)
        data.setdefault("add_delay", 15)
        data.setdefault("accounts", [])
        return data
    except (json.JSONDecodeError, OSError):
        print("[!] accounts.json rusak, dibuat ulang kosong.")
        return data_default()


def simpan_data_akun(data):
    ACCOUNTS_FILE.write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def parse_env_manual(path):
    """Baca file .env gaya KEY=VALUE tanpa dependensi tambahan."""
    hasil = {}
    try:
        for baris in Path(path).read_text(encoding="utf-8").splitlines():
            baris = baris.strip()
            if not baris or baris.startswith("#") or "=" not in baris:
                continue
            kunci, nilai = baris.split("=", 1)
            hasil[kunci.strip()] = nilai.strip()
    except OSError:
        pass
    return hasil


def migrasi_dari_env(data):
    """Sekali saja: kalau accounts masih kosong tapi ada .env v1,
    impor akun v1 (termasuk sesi lamanya kalau ada) jadi 'akun1'."""
    if data["accounts"]:
        return data
    env = parse_env_manual(BASE / ".env")
    try:
        api_id = int(env.get("API_ID", "0"))
    except ValueError:
        api_id = 0
    api_hash = env.get("API_HASH", "").strip()
    if not api_id or not api_hash:
        return data
    SESSIONS_DIR.mkdir(exist_ok=True)
    sesi_lama = BASE / "userbot_session.session"
    sesi_baru = SESSIONS_DIR / "akun1.session"
    if sesi_lama.exists() and not sesi_baru.exists():
        shutil.move(str(sesi_lama), str(sesi_baru))
    data["accounts"].append(
        {
            "name": "akun1",
            "api_id": api_id,
            "api_hash": api_hash,
            "phone": env.get("PHONE", "").strip(),
            "session": "sessions/akun1",
        }
    )
    data["active"] = "akun1"
    simpan_data_akun(data)
    print("[*] Akun v1 dari .env diimpor otomatis jadi 'akun1'.")
    return data


def cari_akun(data, nama):
    for akun in data["accounts"]:
        if akun["name"] == nama:
            return akun
    return None


def buat_client(akun):
    SESSIONS_DIR.mkdir(exist_ok=True)
    return TelegramClient(akun["session"], akun["api_id"], akun["api_hash"])


def mask_api_hash(api_hash):
    if len(api_hash) <= 4:
        return "****"
    return api_hash[:4] + "****"


def tampilkan_daftar_akun(data, perlu_nomor=True):
    if not data["accounts"]:
        print("[!] Belum ada akun. Tambah dulu lewat menu Accounts.")
        return False
    print()
    for i, akun in enumerate(data["accounts"], start=1):
        aktif = "  <-- AKTIF" if akun["name"] == data.get("active") else ""
        print(f"{i}. {akun['name']} | {akun.get('phone') or '-'}"
              f" | api_id {akun['api_id']} | api_hash "
              f"{mask_api_hash(akun['api_hash'])}{aktif}")
    return True


def pilih_akun_dari_daftar(data, aksi=""):
    if not tampilkan_daftar_akun(data):
        return None
    try:
        nomor = int(input(f"Pilih nomor akun{aksi}: ").strip())
        return data["accounts"][nomor - 1]
    except (ValueError, IndexError):
        print("[!] Nomor tidak valid.")
        return None


# ---------------------------------------------------------------------------
# Menu Accounts
# ---------------------------------------------------------------------------

async def tambah_akun_baru(data):
    print("\n=== Add New Account ===")
    nama = input("Nama akun (bebas, mis. akun1): ").strip()
    if not nama:
        print("[!] Nama tidak boleh kosong.")
        return data
    if cari_akun(data, nama):
        print(f"[!] Nama '{nama}' sudah dipakai.")
        return data
    try:
        api_id = int(input("api_id (dari my.telegram.org): ").strip())
    except ValueError:
        print("[!] api_id harus angka.")
        return data
    api_hash = input("api_hash: ").strip()
    if not api_hash:
        print("[!] api_hash tidak boleh kosong.")
        return data
    phone = input("Nomor HP (format +62...): ").strip()

    akun = {
        "name": nama,
        "api_id": api_id,
        "api_hash": api_hash,
        "phone": phone,
        "session": f"sessions/{nama}",
    }
    print(f"\n[*] Login '{nama}' ... (masukkan kode OTP dari Telegram)")
    client = buat_client(akun)
    try:
        await client.start(phone=phone or None)
        me = await client.get_me()
        print(f"[+] Akun '{nama}' berhasil login sebagai "
              f"{me.first_name} (@{me.username or '-'})")
        data["accounts"].append(akun)
        if len(data["accounts"]) == 1:
            data["active"] = nama
            print("[*] Akun pertama otomatis jadi akun aktif.")
        simpan_data_akun(data)
    except Exception as e:  # noqa: BLE001 - tampilkan apa adanya ke user
        print(f"[!] Login gagal: {e}")
    finally:
        await client.disconnect()
    return data


async def cek_satu_akun(akun):
    """Kembalikan: 'OK', 'BANNED', atau 'UNKNOWN: <pesan>'."""
    client = buat_client(akun)
    try:
        await asyncio.wait_for(client.connect(), timeout=30)
        await asyncio.wait_for(client.get_me(), timeout=30)
        return "OK"
    except BANNED_ERRORS:
        return "BANNED"
    except Exception as e:  # noqa: BLE001
        nama_error = type(e).__name__.lower()
        if any(k in nama_error for k in ("deactiv", "banned", "revoked",
                                         "unregistered")):
            return "BANNED"
        return f"UNKNOWN: {type(e).__name__}"
    finally:
        try:
            await client.disconnect()
        except Exception:  # noqa: BLE001
            pass


async def filter_banned(data):
    print("\n=== Filter All Banned Accounts ===")
    if not data["accounts"]:
        print("[!] Belum ada akun.")
        return
    banned, ok, unknown = [], [], []
    for akun in data["accounts"]:
        print(f"[*] Mengecek '{akun['name']}' ...", end=" ", flush=True)
        status = await cek_satu_akun(akun)
        print(status)
        if status == "BANNED":
            banned.append(akun["name"])
        elif status == "OK":
            ok.append(akun["name"])
        else:
            unknown.append((akun["name"], status))
    print(f"\nRingkasan: {len(ok)} OK, {len(banned)} BANNED, "
          f"{len(unknown)} tidak jelas.")
    if banned:
        print("Akun BANNED:")
        for nama in banned:
            print(f"  - {nama}")
        print("Hapus yang banned lewat menu Accounts -> Delete specific account.")
    if unknown:
        print("Akun tidak jelas (kemungkinan jaringan, coba cek ulang):")
        for nama, status in unknown:
            print(f"  - {nama}: {status}")


def hapus_akun(data):
    print("\n=== Delete Specific Account ===")
    akun = pilih_akun_dari_daftar(data, " yang mau dihapus")
    if not akun:
        return data
    konfirmasi = input(f"Ketik 'y' untuk menghapus '{akun['name']}': "
                        ).strip().lower()
    if konfirmasi != "y":
        print("[*] Dibatalkan.")
        return data
    sesi = Path(BASE / (akun["session"] + ".session"))
    try:
        if sesi.exists():
            sesi.unlink()
    except OSError as e:
        print(f"[!] File sesi gagal dihapus: {e}")
    data["accounts"] = [a for a in data["accounts"]
                        if a["name"] != akun["name"]]
    if data.get("active") == akun["name"]:
        data["active"] = None
    simpan_data_akun(data)
    print(f"[+] Akun '{akun['name']}' dihapus.")
    return data


def tampilkan_semua_akun(data):
    print("\n=== Display All Accounts ===")
    if tampilkan_daftar_akun(data):
        print(f"\nTotal: {len(data['accounts'])} akun | "
              f"aktif: {data.get('active') or '-'} | "
              f"jeda tambah member: {data.get('add_delay', 15)} detik")


def set_akun_aktif(data):
    print("\n=== Set Active Account ===")
    akun = pilih_akun_dari_daftar(data, " yang jadi aktif")
    if not akun:
        return data
    data["active"] = akun["name"]
    simpan_data_akun(data)
    print(f"[+] Akun aktif sekarang: '{akun['name']}'.")
    return data


async def menu_accounts(data):
    while True:
        print("\n--- Menu Accounts ---")
        print("1. Add new account")
        print("2. Filter all banned accounts")
        print("3. Delete specific account")
        print("4. Display all accounts")
        print("5. Set active account")
        print("0. Kembali")
        pilih = input("Pilih (0-5): ").strip()
        if pilih == "1":
            data = await tambah_akun_baru(data)
        elif pilih == "2":
            await filter_banned(data)
        elif pilih == "3":
            data = hapus_akun(data)
        elif pilih == "4":
            tampilkan_semua_akun(data)
        elif pilih == "5":
            data = set_akun_aktif(data)
        elif pilih == "0":
            break
        else:
            print("[!] Pilihan tidak dikenal.")
    return data


# ---------------------------------------------------------------------------
# Akun aktif untuk aksi
# ---------------------------------------------------------------------------

def pilih_akun_aktif(data):
    """Tentukan akun untuk aksi. Otomatis kalau cuma 1 akun / sudah diset."""
    if not data["accounts"]:
        print("\n[!] Belum ada akun. Tambah dulu di menu Accounts.")
        return None
    if len(data["accounts"]) == 1:
        return data["accounts"][0]
    aktif = cari_akun(data, data.get("active"))
    if aktif:
        return aktif
    print("\n[*] Akun aktif belum diset. Pilih akun untuk aksi ini:")
    akun = pilih_akun_dari_daftar(data)
    if akun:
        data["active"] = akun["name"]
        simpan_data_akun(data)
    return akun


async def buka_client_aktif(data):
    """Buka client akun aktif. Kembalikan (client, akun) atau (None, None)."""
    akun = pilih_akun_aktif(data)
    if not akun:
        return None, None
    client = buat_client(akun)
    try:
        await client.start(phone=akun.get("phone") or None)
    except Exception as e:  # noqa: BLE001
        print(f"[!] Gagal membuka akun '{akun['name']}': {e}")
        await client.disconnect()
        return None, None
    me = await client.get_me()
    print(f"[*] Memakai akun: {me.first_name} (@{me.username or '-'})")
    return client, akun


# ---------------------------------------------------------------------------
# Grup: buat, simpan, info
# ---------------------------------------------------------------------------

def simpan_grup(channel, invite_link):
    data = {
        "title": channel.title,
        "id": channel.id,
        "invite_link": invite_link,
    }
    GROUP_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return data


def baca_grup():
    if not GROUP_FILE.exists():
        return None
    try:
        return json.loads(GROUP_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


async def ambil_entity_grup_tersimpan(client):
    data = baca_grup()
    if not data:
        print("\n[!] Belum ada grup tersimpan. Pilih menu buat grup baru dulu.")
        return None, None
    try:
        channel = await client.get_entity(PeerChannel(data["id"]))
    except Exception as e:  # noqa: BLE001
        print(f"\n[!] Grup tersimpan tidak bisa dibuka: {e}")
        return None, None
    return channel, data


async def buat_grup(client):
    print("\n=== Buat Grup Baru ===")
    title = input("Nama grup: ").strip()
    if not title:
        print("[!] Nama grup tidak boleh kosong.")
        return
    about = input("Deskripsi grup (boleh kosong): ").strip()

    print(f"\n[*] Membuat supergroup '{title}' ...")
    try:
        result = await client(
            CreateChannelRequest(title=title, about=about, megagroup=True)
        )
    except FloodWaitError as e:
        print(f"[!] Kena FloodWait Telegram. Tunggu {e.seconds} detik lalu coba lagi.")
        return
    except Exception as e:  # noqa: BLE001
        print(f"[!] Gagal membuat grup: {e}")
        return

    channel = result.chats[0]
    try:
        invite = await client(ExportChatInviteRequest(channel))
        link = invite.link
    except Exception:  # noqa: BLE001 - invite link opsional, grup tetap jadi
        link = "-"

    simpan_grup(channel, link)
    print("\n[+] Grup berhasil dibuat!")
    print(f"    Nama       : {channel.title}")
    print(f"    ID         : {channel.id}")
    print(f"    Invite link: {link}")
    print("    (Info grup disimpan di group.json untuk menu tambah member.)")


async def info_grup(client):
    print("\n=== Info Grup Tersimpan ===")
    channel, data = await ambil_entity_grup_tersimpan(client)
    if not channel:
        return
    try:
        full = await client(GetFullChannelRequest(channel))
        jumlah = full.full_chat.participants_count
    except Exception:  # noqa: BLE001
        jumlah = "?"
    print(f"Nama         : {channel.title}")
    print(f"ID           : {channel.id}")
    print(f"Jumlah member: {jumlah}")
    print(f"Invite link  : {data.get('invite_link', '-')}")


# ---------------------------------------------------------------------------
# Invite member (dipakai menu file & menu dump)
# ---------------------------------------------------------------------------

async def invite_daftar(client, channel, usernames, delay):
    """Invite daftar username ke channel. Kembalikan (ok, lewati, gagal)."""
    berhasil = dilewati = gagal = 0
    try:
        for i, username in enumerate(usernames, start=1):
            tag = f"[{i}/{len(usernames)}] @{username}"
            try:
                user = await client.get_entity(username)
            except Exception:
                print(f"{tag} -> LEWAT (username tidak ditemukan)")
                dilewati += 1
                continue

            percobaan = 0
            while True:
                try:
                    await client(
                        InviteToChannelRequest(
                            channel,
                            [InputUser(user.id, user.access_hash)],
                        )
                    )
                    print(f"{tag} -> OK")
                    berhasil += 1
                    break
                except FloodWaitError as e:
                    percobaan += 1
                    if percobaan > 1:
                        print(f"{tag} -> BERHENTI (FloodWait berulang: "
                              f"{e.seconds} detik)")
                        print("\n[!] Telegram membatasi penambahan. "
                              "Istirahatkan akun dulu, lanjutkan lagi nanti.")
                        print(f"\nRingkasan: {berhasil} OK, {dilewati} "
                              f"dilewati, {gagal} gagal.")
                        return berhasil, dilewati, gagal
                    print(f"{tag} -> FloodWait {e.seconds} detik, tidur dulu ...")
                    await asyncio.sleep(e.seconds + 5)
                except (UserPrivacyRestrictedError, PeerFloodError):
                    print(f"{tag} -> LEWAT (user membatasi siapa yang bisa "
                          "menambahkannya)")
                    dilewati += 1
                    break
                except ChatAdminRequiredError:
                    print("[!] Akun ini bukan admin grup tujuan. Berhenti.")
                    print(f"\nRingkasan: {berhasil} OK, {dilewati} "
                          f"dilewati, {gagal} gagal.")
                    return berhasil, dilewati, gagal
                except Exception as e:  # noqa: BLE001
                    print(f"{tag} -> GAGAL ({e})")
                    gagal += 1
                    break

            if i < len(usernames):
                await asyncio.sleep(delay)
    except KeyboardInterrupt:
        print("\n\n[!] Dihentikan oleh user (Ctrl+C).")

    print(f"\nSelesai. Ringkasan: {berhasil} OK, {dilewati} dilewati, "
          f"{gagal} gagal.")
    return berhasil, dilewati, gagal


def baca_members_file():
    """Baca members.txt: satu username per baris, '@' boleh ada/tidak."""
    if not MEMBERS_FILE.exists():
        print("\n[!] File members.txt tidak ditemukan.")
        print("    Isi members.txt dengan satu username per baris, contoh:")
        print("      @username1")
        print("      username2")
        return []
    members = []
    for baris in MEMBERS_FILE.read_text(encoding="utf-8").splitlines():
        nama = baris.strip()
        if not nama or nama.startswith("#"):
            continue
        members.append(nama.lstrip("@"))
    return members


async def tambah_member_dari_file(client, data):
    print("\n=== Tambah Member dari members.txt ===")
    channel, info = await ambil_entity_grup_tersimpan(client)
    if not channel:
        return
    members = baca_members_file()
    if not members:
        print("[!] members.txt kosong. Isi dulu daftar username-nya.")
        return
    delay = data.get("add_delay", 15)
    print(f"Grup target  : {info['title']} (ID {info['id']})")
    print(f"Total antrian: {len(members)} username | jeda {delay} detik/member")
    print("Tekan Ctrl+C kapan saja untuk berhenti.\n")
    await invite_daftar(client, channel, members, delay)


# ---------------------------------------------------------------------------
# Dump member dari grup lain -> invite ke grup tujuan
# ---------------------------------------------------------------------------

def ekstrak_hash_invite(link):
    """Ambil hash dari link invite t.me/joinchat/... atau t.me/+... .
    Kembalikan None kalau bukan link invite."""
    link = link.strip()
    if "joinchat/" in link:
        return link.split("joinchat/", 1)[1].split("/")[0].split("?")[0].strip()
    if "/+" in link:
        return link.split("/+", 1)[1].split("/")[0].split("?")[0].strip()
    return None


def ekstrak_username_publik(link):
    """Ambil username dari link publik t.me/nama atau @nama atau nama."""
    link = link.strip()
    if "/" in link:
        link = link.rsplit("/", 1)[-1]
    return link.split("?")[0].lstrip("@").strip()


async def resolve_grup(client, link, keterangan):
    """Ubah link grup (publik/invite) jadi entity channel.
    Untuk link invite, akun akan join dulu kalau belum member."""
    link = link.strip()
    if not link:
        return None
    hash_invite = ekstrak_hash_invite(link)
    if hash_invite:
        try:
            cek = await client(CheckChatInviteRequest(hash_invite))
            if cek.chat:
                return cek.chat
            hasil = await client(ImportChatInviteRequest(hash_invite))
            return hasil.chats[0]
        except UserAlreadyParticipantError:
            try:
                cek = await client(CheckChatInviteRequest(hash_invite))
                if cek.chat:
                    return cek.chat
            except Exception:  # noqa: BLE001
                pass
            print(f"[!] {keterangan}: sudah member tapi entity tidak "
                  "ditemukan. Coba pakai @username grup kalau ada.")
            return None
        except InviteHashExpiredError:
            print(f"[!] {keterangan}: link invite sudah kedaluwarsa.")
            return None
        except Exception as e:  # noqa: BLE001
            print(f"[!] {keterangan}: gagal membuka link ({e})")
            return None
    username = ekstrak_username_publik(link)
    if not username:
        print(f"[!] {keterangan}: link tidak dikenali.")
        return None
    try:
        return await client.get_entity(username)
    except Exception as e:  # noqa: BLE001
        print(f"[!] {keterangan}: grup tidak ditemukan ({e})")
        return None


def nama_file_dump(channel):
    dasar = re.sub(r"[^A-Za-z0-9_]+", "_", channel.title or "grup").strip("_")
    return DUMP_DIR / f"dump_{dasar}_{channel.id}.txt"


async def dump_member(client, sumber):
    """Dump semua username dari grup sumber. Kembalikan list username."""
    print(f"\n[*] Mendump member dari '{sumber.title}' ... (bisa agak lama "
          "untuk grup besar)")
    try:
        me = await client.get_me()
    except Exception:  # noqa: BLE001
        me = None
    hasil = []
    try:
        async for user in client.iter_participants(sumber):
            if user is None or getattr(user, "bot", False):
                continue
            if me is not None and user.id == me.id:
                continue
            if user.username:
                hasil.append(user.username)
    except FloodWaitError as e:
        print(f"[!] Kena FloodWait saat dump ({e.seconds} detik). "
              "Dump parsial tetap disimpan.")
    except ChannelPrivateError:
        print("[!] Grup sumber privat / akun ini belum gabung grup sumber.")
        return []
    except Exception as e:  # noqa: BLE001
        print(f"[!] Gagal dump: {e}")
        return []
    return hasil


async def tambah_member_dari_grup(client, data):
    print("\n=== Tambah Member dari Grup Lain ===")
    print("Alur: link grup tujuan -> link grup sumber -> dump username "
          "-> invite ke grup tujuan.")
    link_tujuan = input("\nLink grup TUJUAN: ").strip()
    tujuan = await resolve_grup(client, link_tujuan, "Grup tujuan")
    if not tujuan:
        return
    print(f"[*] Tujuan: {tujuan.title} (ID {tujuan.id})")

    link_sumber = input("Link grup SUMBER (random): ").strip()
    sumber = await resolve_grup(client, link_sumber, "Grup sumber")
    if not sumber:
        return
    print(f"[*] Sumber: {sumber.title} (ID {sumber.id})")

    usernames = await dump_member(client, sumber)
    if not usernames:
        print("[!] Tidak ada username yang bisa didump dari grup sumber.")
        return
    file_dump = nama_file_dump(sumber)
    file_dump.write_text("\n".join(f"@{u}" for u in usernames),
                         encoding="utf-8")
    print(f"\n[+] Dump selesai: {len(usernames)} username "
          f"(disimpan di {file_dump.name})")

    maks = input("Mau invite berapa member? (Enter = semua): ").strip()
    try:
        maks_n = int(maks) if maks else len(usernames)
    except ValueError:
        maks_n = len(usernames)
    target_list = usernames[:max(maks_n, 0)]
    if not target_list:
        print("[!] Tidak ada yang diinvite.")
        return

    konfirmasi = input(f"Invite {len(target_list)} member ke "
                       f"'{tujuan.title}'? ketik 'y' untuk lanjut: "
                       ).strip().lower()
    if konfirmasi != "y":
        print("[*] Dibatalkan. File dump tetap tersimpan.")
        return

    delay = data.get("add_delay", 15)
    print(f"\n[*] Mulai invite | jeda {delay} detik/member | "
          "Ctrl+C untuk berhenti.\n")
    await invite_daftar(client, tujuan, target_list, delay)


# ---------------------------------------------------------------------------
# Menu utama
# ---------------------------------------------------------------------------

async def main():
    print("=== Telegram Userbot (API Dev) v2 ===")
    data = migrasi_dari_env(muat_data_akun())
    if not data["accounts"]:
        print("[*] Belum ada akun. Buka menu Accounts -> Add new account dulu.")
    else:
        print(f"[*] {len(data['accounts'])} akun tersimpan | "
              f"aktif: {data.get('active') or '-'}")

    while True:
        data = muat_data_akun()
        print("\n--- Menu Utama ---")
        print("1. Accounts")
        print("2. Buat grup baru")
        print("3. Tambah member dari members.txt")
        print("4. Tambah member dari grup lain (dump + invite)")
        print("5. Info grup tersimpan")
        print("0. Keluar")
        pilih = input("Pilih (0-5): ").strip()

        if pilih == "1":
            data = await menu_accounts(data)
            continue
        if pilih == "0":
            print("Sampai jumpa, Bro.")
            break
        if pilih not in ("2", "3", "4", "5"):
            print("[!] Pilihan tidak dikenal.")
            continue

        client, akun = await buka_client_aktif(data)
        if not client:
            continue
        try:
            if pilih == "2":
                await buat_grup(client)
            elif pilih == "3":
                await tambah_member_dari_file(client, data)
            elif pilih == "4":
                await tambah_member_dari_grup(client, data)
            elif pilih == "5":
                await info_grup(client)
        finally:
            await client.disconnect()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nKeluar.")
